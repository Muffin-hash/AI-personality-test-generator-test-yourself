export interface PersonalityOption {
  text: string;
  traitImpacts: {
    [trait: string]: number; // e.g., { extroversion: 1, introversion: -1 }
  };
}

export interface PersonalityQuestion {
  id: string;
  text: string;
  options: PersonalityOption[];
}

export interface PersonalityTrait {
  name: string;
  description: string;
}

export interface PersonalityTest {
  title: string;
  description: string;
  traits: PersonalityTrait[];
  questions: PersonalityQuestion[];
}

export interface TestResult {
  traits: {
    [trait: string]: number;
  };
  summary: string;
  detailedAnalysis: string;
}
