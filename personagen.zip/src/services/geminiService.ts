import { GoogleGenAI, Type } from "@google/genai";
import { PersonalityTest, TestResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function generatePersonalityTest(userInput: string): Promise<PersonalityTest> {
  const prompt = `Generate a personality test based on the following theme/context: "${userInput}".
  The test should have 5-7 questions. Each question should have 3-4 options.
  Each option should impact specific personality traits defined in the test.
  Return the result in JSON format matching the PersonalityTest interface.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          traits: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                description: { type: Type.STRING }
              },
              required: ["name", "description"]
            }
          },
          questions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                text: { type: Type.STRING },
                options: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      text: { type: Type.STRING },
                      traitImpacts: {
                        type: Type.OBJECT,
                        additionalProperties: { type: Type.NUMBER }
                      }
                    },
                    required: ["text", "traitImpacts"]
                  }
                }
              },
              required: ["id", "text", "options"]
            }
          }
        },
        required: ["title", "description", "traits", "questions"]
      }
    }
  });

  return JSON.parse(response.text);
}

export async function analyzeResults(
  test: PersonalityTest,
  answers: { [questionId: string]: string },
  traitScores: { [trait: string]: number }
): Promise<TestResult> {
  const prompt = `Analyze the results of a personality test called "${test.title}".
  Test Description: ${test.description}
  The user achieved the following trait scores: ${JSON.stringify(traitScores)}
  The traits monitored were: ${JSON.stringify(test.traits)}
  
  Provide a friendly, insightful summary and a detailed analysis of their personality based on these scores.
  Return the result in JSON format with "summary" and "detailedAnalysis" fields.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING },
          detailedAnalysis: { type: Type.STRING }
        },
        required: ["summary", "detailedAnalysis"]
      }
    }
  });

  const analysis = JSON.parse(response.text);
  return {
    traits: traitScores,
    summary: analysis.summary,
    detailedAnalysis: analysis.detailedAnalysis
  };
}
