/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  BrainCircuit, 
  ArrowRight, 
  RefreshCw, 
  CheckCircle2, 
  ChevronRight,
  User,
  Zap,
  Star,
  Loader2
} from 'lucide-react';
import { PersonalityTest, TestResult } from './types';
import { generatePersonalityTest, analyzeResults } from './services/geminiService';

type AppState = 'landing' | 'generating' | 'taking_test' | 'analyzing' | 'results';

export default function App() {
  const [state, setState] = useState<AppState>('landing');
  const [inputTopic, setInputTopic] = useState('');
  const [test, setTest] = useState<PersonalityTest | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<{ [id: string]: number }>({});
  const [result, setResult] = useState<TestResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const startGeneration = async () => {
    if (!inputTopic.trim()) return;
    setState('generating');
    setError(null);
    try {
      const generatedTest = await generatePersonalityTest(inputTopic);
      setTest(generatedTest);
      setState('taking_test');
      setCurrentQuestionIndex(0);
      setAnswers({});
    } catch (err) {
      console.error(err);
      setError('Failed to generate test. Please try again.');
      setState('landing');
    }
  };

  const handleAnswerSelection = (optionIndex: number) => {
    if (!test) return;
    const question = test.questions[currentQuestionIndex];
    const newAnswers = { ...answers, [question.id]: optionIndex };
    setAnswers(newAnswers);

    if (currentQuestionIndex < test.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      finishTest(newAnswers);
    }
  };

  const finishTest = async (finalAnswers: { [id: string]: number }) => {
    if (!test) return;
    setState('analyzing');
    
    // Calculate raw scores
    const scores: { [trait: string]: number } = {};
    test.traits.forEach(t => scores[t.name] = 0);

    test.questions.forEach(q => {
      const selectedOptionIndex = finalAnswers[q.id];
      const selectedOption = q.options[selectedOptionIndex];
      Object.entries(selectedOption.traitImpacts).forEach(([trait, impact]) => {
        const val = impact as number;
        if (scores[trait] !== undefined) {
          scores[trait] += val;
        } else {
          scores[trait] = val;
        }
      });
    });

    try {
      const analysis = await analyzeResults(test, {}, scores);
      setResult(analysis);
      setState('results');
    } catch (err) {
      console.error(err);
      setError('Failed to analyze results.');
      setState('landing');
    }
  };

  const reset = () => {
    setState('landing');
    setInputTopic('');
    setTest(null);
    setResult(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-[#FFF9F2] flex flex-col items-center p-6 text-slate-800">
      {/* Abstract Background Decor */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none opacity-20">
        <div className="absolute -top-20 -left-20 w-[40rem] h-[40rem] bg-indigo-200 blur-[150px] rounded-full" />
        <div className="absolute -bottom-20 -right-20 w-[40rem] h-[40rem] bg-rose-200 blur-[150px] rounded-full" />
      </div>

      {/* Header-like Logo area for landing */}
      {state === 'landing' && (
        <header className="w-full max-w-6xl flex justify-between items-center py-8 z-20">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-[#6366F1] rounded-xl shadow-lg flex items-center justify-center">
               <BrainCircuit className="text-white w-6 h-6" />
             </div>
             <span className="text-2xl font-black tracking-tighter text-slate-900">PersonaGen</span>
          </div>
          <div className="hidden md:flex gap-8 font-bold text-sm text-slate-500">
            <span>Themes</span>
            <span>Analytics</span>
          </div>
        </header>
      )}

      <AnimatePresence mode="wait">
        {state === 'landing' && (
          <motion.div
            key="landing"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="w-full max-w-4xl flex flex-col items-center justify-center flex-1 z-10 text-center"
          >
            <div className="tag mb-6">Explore your psyche</div>
            
            <h1 className="text-7xl md:text-8xl font-black tracking-tight leading-[0.9] text-slate-900 mb-8 max-w-3xl">
              Understand <span className="text-[#6366F1]">Who</span> You Really Are.
            </h1>
            
            <p className="text-xl text-slate-500 font-medium max-w-xl mx-auto leading-relaxed mb-12">
              Generate a custom personality test based on any context. 
              Our AI analyzes your subconscious patterns through the lens of your chosen theme.
            </p>

            <div className="w-full max-w-xl bg-white p-3 rounded-[32px] shadow-[0_20px_0_rgba(0,0,0,0.03)] border border-slate-100 flex items-center">
              <input
                type="text"
                placeholder="Describe a theme (e.g. Life on Mars)"
                value={inputTopic}
                onChange={(e) => setInputTopic(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && startGeneration()}
                className="flex-1 bg-transparent border-none focus:ring-0 px-6 py-4 text-slate-800 placeholder:text-slate-400 text-lg font-semibold"
              />
              <button
                onClick={startGeneration}
                className="btn-primary h-14 px-8 flex items-center gap-2"
              >
                Create Test <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {error && (
              <motion.p 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-rose-500 font-bold mt-6"
              >
                {error}
              </motion.p>
            )}
          </motion.div>
        )}

        {(state === 'generating' || state === 'analyzing') && (
          <motion.div
            key="loading"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.1 }}
            className="flex flex-col items-center justify-center flex-1 z-10 gap-8"
          >
            <div className="relative">
              <div className="absolute inset-0 bg-indigo-500/20 blur-3xl rounded-full" />
              <div className="bg-white p-10 rounded-[40px] shadow-2xl border-b-8 border-indigo-600">
                <Loader2 className="w-20 h-20 text-indigo-500 animate-spin" />
              </div>
            </div>
            <div className="text-center space-y-2">
              <h2 className="text-4xl font-black text-slate-900">
                {state === 'generating' ? 'Drafting Questions...' : 'Deep Scanning Traits...'}
              </h2>
              <p className="text-slate-500 font-bold text-lg">
                The AI is configuring your personal analysis matrix.
              </p>
            </div>
          </motion.div>
        )}

        {state === 'taking_test' && test && (
          <motion.div
            key="taking_test"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="w-full max-w-5xl flex-1 flex flex-col items-center justify-center z-10"
          >
            <div className="w-full flex items-center justify-between mb-12">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white font-bold">
                  {currentQuestionIndex + 1}
                </div>
                <div>
                   <h2 className="text-3xl font-black text-slate-900 tracking-tight">{test.title}</h2>
                   <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">Step {currentQuestionIndex + 1} of {test.questions.length}</p>
                </div>
              </div>
              <div className="h-4 w-48 bg-slate-200 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-indigo-500"
                  initial={{ width: 0 }}
                  animate={{ width: `${((currentQuestionIndex + 1) / test.questions.length) * 100}%` }}
                />
              </div>
            </div>

            <div className="bg-white rounded-[48px] p-16 shadow-[0_24px_0_rgba(0,0,0,0.04)] border border-slate-100 max-w-4xl w-full">
              <h4 className="text-4xl font-bold leading-tight text-slate-900 mb-16">
                {test.questions[currentQuestionIndex].text}
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {test.questions[currentQuestionIndex].options.map((option, idx) => (
                  <motion.button
                    key={idx}
                    whileHover={{ y: -4, shadow: '0 12px 24px rgba(0,0,0,0.1)' }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleAnswerSelection(idx)}
                    className="flex items-center justify-between p-8 rounded-[32px] border-4 border-slate-100 bg-slate-50/50 text-left transition-all hover:border-indigo-200 hover:bg-indigo-50 group"
                  >
                    <span className="text-xl font-bold text-slate-700 group-hover:text-indigo-900">{option.text}</span>
                    <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center border-2 border-slate-200 group-hover:border-indigo-400 group-hover:bg-indigo-600 transition-colors">
                      <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-white" />
                    </div>
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {state === 'results' && result && (
          <motion.div
            key="results"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-12 gap-8 z-10 py-12"
          >
            {/* Sidebar Column */}
            <div className="lg:col-span-4 flex flex-col gap-8">
              <div className="card text-center flex flex-col items-center">
                <div className="w-24 h-24 rounded-full bg-amber-400 border-4 border-white shadow-xl flex items-center justify-center text-4xl mb-6">
                   <User className="w-12 h-12 text-white" />
                </div>
                <h3 className="text-2xl font-black text-slate-900">Psychology Profile</h3>
                <p className="text-slate-500 font-bold text-sm">Analyzed via Identity matrix</p>
                <div className="mt-8 pt-8 border-t border-slate-100 w-full">
                  <p className="text-xs font-black uppercase tracking-widest text-slate-400 mb-2">Confidence Rating</p>
                  <div className="text-4xl font-black text-[#10B981]">98%</div>
                </div>
              </div>

              <div className="card flex-1">
                <h3 className="text-sm font-black uppercase tracking-widest text-slate-400 mb-8">Trait Metrics</h3>
                <div className="space-y-8">
                  {Object.entries(result.traits).map(([trait, rawScore], idx) => {
                    const score = rawScore as number;
                    const colors = [
                      'bg-[#6366F1]', // Indigo
                      'bg-[#F43F5E]', // Rose
                      'bg-[#F59E0B]', // Amber
                      'bg-[#10B981]', // Emerald
                    ];
                    return (
                      <div key={trait} className="space-y-3">
                        <div className="flex justify-between items-center text-sm font-bold">
                          <span className="text-slate-800">{trait}</span>
                          <span className="text-slate-500">{score > 0 ? `+${score}` : score}</span>
                        </div>
                        <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden">
                          <motion.div 
                            className={`h-full ${colors[idx % colors.length]}`}
                            initial={{ width: 0 }}
                            animate={{ width: `${Math.min(100, Math.max(5, (score + 10) * 5))}%` }}
                            transition={{ duration: 1.5, ease: 'backOut' }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Main Result Column */}
            <div className="lg:col-span-8 flex flex-col gap-8">
              <div className="hero-gradient p-12 md:p-16 rounded-[48px] text-white flex justify-between items-center relative overflow-hidden shadow-2xl">
                <div className="z-10 max-w-2xl">
                  <h1 className="text-6xl md:text-7xl font-black leading-[0.9] mb-4">The Persona Summary</h1>
                  <p className="text-xl md:text-2xl font-medium opacity-90 leading-relaxed text-indigo-50 border-l-4 border-white/30 pl-6">
                    {result.summary}
                  </p>
                </div>
                <div className="absolute top-[-40px] right-[-40px] w-64 h-64 bg-white/10 rounded-full blur-3xl" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-1 gap-8">
                <div className="card relative h-fit group">
                  <div className="flex items-center gap-4 mb-8">
                    <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center text-white shadow-lg">
                      <BrainCircuit className="w-6 h-6" />
                    </div>
                    <h3 className="text-3xl font-black text-slate-900 tracking-tight">Depth Analysis</h3>
                  </div>
                  <div className="space-y-6 text-lg text-slate-600 font-medium leading-relaxed">
                    {result.detailedAnalysis.split('\n').map((para, i) => (
                      <p key={i}>{para}</p>
                    ))}
                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={reset}
                    className="btn-primary flex-1 py-8 text-2xl shadow-[0_12px_24px_rgba(99,102,241,0.2)]"
                  >
                    Start New Discovery
                  </button>
                  <button className="bg-slate-900 text-white rounded-3xl px-12 font-black text-2xl flex items-center gap-4 shadow-xl">
                    Share <Star className="fill-white w-6 h-6" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <footer className="mt-auto py-12 w-full max-w-6xl flex justify-between items-center border-t border-slate-200 z-10">
        <div className="flex items-center gap-4 text-slate-400 text-xs font-black uppercase tracking-[0.3em]">
           <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
           PersonaGen Engine v2.0
        </div>
        <div className="flex gap-12 font-black text-xs uppercase tracking-widest text-slate-400">
          <span>Identity Protocol</span>
          <span>© 2026</span>
        </div>
      </footer>
    </div>
  );
}

